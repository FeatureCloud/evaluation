/usr/bin/supervisord -c "/supervisord.conf"
