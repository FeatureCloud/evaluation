# from logging import DEBUG, ERROR, INFO
from FeatureCloud.app.engine.app import AppState, app_state, Role, LogLevel
from MyModel import MyModel         # *** for transfer learning, simple neural network
from MyModel import MyModel        # *** lstm,  uncomment, and also provide config_sequence.yml 
# (in read_write.py, line 18)  

import itertools 
# from sklearn.metrics import classification_report
# from sklearn.metrics import confusion_matrix
import numpy as np 

myLogLevel = 'DEBUG' 
# *********************************************************************
# FUNCTIONS 
# *********************************************************************
from utils.read_write import read_config, log_config_params, store_params, \
    log_parameter_names, write_results, store_dataloaders,\
    read_model, findOccurrences, read_trlr_params, log_dataloader_list, save_model
from utils.transform import data_loader_lists
from utils.train_test import update_iteration, set_the_weights, agregate_params, extract_model_definition, \
    update_train_errors, freeze_all_parameters, find_trainable_params, remove_from_param_dict, \
    log_children_params, log_layer_list, log_layers_to_change, change_selected_layers

# *********************************************************************
# STATES 
# *********************************************************************
INITIAL_STATE = 'initial'
CREATE_MODEL = 'create_model'
COMPUTE_STATE = 'compute'
AGGREGATE_STATE = 'aggregate'
WRITE_STATE = 'write'
TERMINAL_STATE = 'terminal'



# ****************************************************************
# INITIAL STATE / READ THE DATA
# ****************************************************************
@app_state(name=INITIAL_STATE, role=Role.BOTH)
class InitialState(AppState):

    def register(self):
        self.register_transition(CREATE_MODEL, role = Role.COORDINATOR)
        self.register_transition(COMPUTE_STATE, role = Role.PARTICIPANT)

    def run(self):
        self.log('################## INITIAL STATE #######################', LogLevel.DEBUG)
        self.log('Reading configuration file...')

        train_inputs, train_targets, test_inputs, test_targets, input_sep, max_iters, device, batch_size = read_config()

        self.log('Config parameters:')
        log_config_params(train_inputs, train_targets, test_inputs, test_targets, input_sep, max_iters, device, batch_size, self)

        self.log('Storing config parameters...')   
        store_params(train_inputs, train_targets, test_inputs, test_targets, input_sep, max_iters, device, batch_size, self)
    
        self.log('Making datasets and dataloaders...')                                 
        train_dataloaders, test_dataloaders = data_loader_lists(train_inputs, train_targets, test_inputs, test_targets, batch_size, input_sep, device, self)
        log_dataloader_list(train_dataloaders, test_dataloaders, self)
        
        self.log('Storing train and test dataloaders...')
        store_dataloaders(train_dataloaders, test_dataloaders, self)

        self.log('Storing iterations...')
        iteration = 0
        self.log(f'******ITERATION: {iteration}, initialization**************')
        self.store('iteration', iteration)
        self.store('model_params_dict_agr', None)       # agregation hasn't happened yet 

        train_errors = []                               # update it after every epoch
        self.store('train_errors', train_errors) 

        if self.is_coordinator:
            return CREATE_MODEL
        else:
            return COMPUTE_STATE
          




# ****************************************************************
# CREATE A MODEL 
# ****************************************************************
@app_state(name=CREATE_MODEL, role = Role.COORDINATOR)
class CreateModel(AppState):
    def register(self):
        self.register_transition(COMPUTE_STATE, role = Role.COORDINATOR)
    def run(self):
        self.log('################## CREATE MODEL #######################', LogLevel.DEBUG)
        self.log('Prepairing the initial model...')
        
        # Create the model, set the criterion, and the optimizer.
        device = self.load('device')
        model = MyModel().to(device)
        self.log('Check transfer learning...')
        tr_lrnng = self.load('transfer_learning')    
        if tr_lrnng == 'y':
            model_pretrained, layers_to_change_are_children_of, layer_indices_in_the_list = read_trlr_params(self)

            # pretrained model
            model = read_model(model, model_pretrained)
            self.log(f'Pretrained model: {model}')  

            self.log(f'******Freeze the layers**************')
            freeze_all_parameters(model)      
            dot_index = findOccurrences(layers_to_change_are_children_of, '.')   # find the layer whose weights should be frozen 
            if len(dot_index) == 1:                                              # check if it's our general case scenario
                log_layer_list(model, self)     
                child_string = layers_to_change_are_children_of.split(".", 1)[1] # limit the number of splits to 1 
                layers_to_change = getattr(model, child_string)
                layers_to_change_list = list(layers_to_change)  
                log_layers_to_change(child_string, layers_to_change, layers_to_change_list, self)

                self.log(f'Layer indices to change: {layer_indices_in_the_list}') 
                layers_to_change = change_selected_layers(layers_to_change_list, layer_indices_in_the_list, self)     # unfreeze 
                setattr(model, child_string, layers_to_change)    

        # Check if you unfreezed params - logs whether param requires grad or not
        log_children_params(model, self)    

        # Make list of parameters that are not frozen and should be trained
        trainable_params_list = find_trainable_params(model, self)                               
        model_dict = {"model": model, "trainable_params_list": trainable_params_list}
        self.log(f'Model dict: {model_dict}')                 

        self.broadcast_data(model_dict)     
        return COMPUTE_STATE



# ****************************************************************
# COMPUTE_STATE / Training, all, send params to coordinator 
# ****************************************************************
@app_state(COMPUTE_STATE)
class ComputeState(AppState):

    def register(self):
        self.register_transition(COMPUTE_STATE, role=Role.PARTICIPANT)
        self.register_transition(AGGREGATE_STATE, role=Role.COORDINATOR)
        self.register_transition(WRITE_STATE, role=Role.BOTH)

    def run(self):
        self.log('################## COMPUTE STATE #######################', LogLevel.DEBUG)
        self.log("Transition to compute state...")
        iteration = self.load('iteration')
        max_iters = self.load('max_iters')
       
        if iteration==0:                             # Receive the global model from the coordinator 
            model_dict = self.await_data()           # await but not load because participants havent entered the create model state 
            self.store('model_dict', model_dict)     # mandatory, there is no more model broadcast, only the parameters broadcast
            model_params_dict_agr = self.load('model_params_dict_agr')             # None in the first iteration 
        else:    
            model_params_dict_agr = self.await_data()
            model_dict = self.load('model_dict')
        
        [model, trainable_params_list] = extract_model_definition(model_dict)      # extract the received model

        iteration = update_iteration(self)                                         # update iteration
        self.log(f'******UPDATED ITERATION: {iteration}**************')

        self.log(f'******Check if done**************')                             # check if the stopping crit. is reached 
        done = iteration > max_iters
        self.log(f'Termination criteria, done: {done}')
        if done:                      
            self.store('model_params_dict_agr', model_params_dict_agr)             # save the final parameters 
            return WRITE_STATE 

        self.log('Reading train dataloaders...')
        train_dataloaders = self.load('train_dataloaders')                         # list of train dataloaders
        self.log(train_dataloaders)

        self.log('**************Training, updating weights****************')
        if model_params_dict_agr!=None:                              # manually update the weights according to agregated params
            set_the_weights(model, model_params_dict_agr, self)          
        train_params_dict, loss_values, X_train = model.train(train_dataloaders)     # training will depend on the number of inputs 
        self.log(f'X_train size: {X_train.size()}')
        self.log(f'Train loss values len: {len(loss_values)}')
        self.log(f'Train dataloaders num od batches: {len(train_dataloaders[0])}')   # dataset_len/batch_size

        self.log('***********************Loss*****************')
        self.log(f'Loss in {iteration} iteration is: {loss_values}')
        update_train_errors(self, loss_values)                                       # add loss to the train errors array 

        self.log('***************Training parameters*******************') 
        log_parameter_names(train_params_dict, self)                                 # lists all parameter names 

        self.log('***********Sending weights to coordinator*********')
        if self.load('transfer_learning') == 'y':                  # check a list of trainable params, don't train all of them
            train_params_dict = remove_from_param_dict(train_params_dict, trainable_params_list)
            self.log('Trainable params for transfer learning:')
            log_parameter_names(train_params_dict, self)                             # lists parameter names 
        self.send_data_to_coordinator(train_params_dict)                             # make model_params_dict_list out of this 
        
        if self.is_coordinator:
            return AGGREGATE_STATE
        else:      
            return COMPUTE_STATE           # participant



# ****************************************************************
# AGGREGATE_STATE / Coordinator aggregates params, sends them back to 
# participants, iter += 1, check all the stopping criteria  
# ****************************************************************
@app_state(AGGREGATE_STATE) 
class AggregateState(AppState):

    def register(self):
        self.register_transition(COMPUTE_STATE, role = Role.COORDINATOR)
            
    def run(self):
        self.log('################## AGGREGATTE STATE #######################')
        self.log('Waiting for local models...')
        model_params_dict_list = self.gather_data()           # a list 

        self.log(f'List of model parameters has: {len(model_params_dict_list)} elements')  
    
        self.log('****************Aggregating models******************')
        key_names = model_params_dict_list[0].keys()          # keys are parameter names, every list member has the same structure
        model_params_dict_agr = agregate_params(model_params_dict_list, key_names)
        self.log('Broadcasting global model back to participants...')
        self.broadcast_data(model_params_dict_agr)
       
        return COMPUTE_STATE




# ***************************************************************************
# WRITE STATE / All, for each participant predict the test labels, terminate  
# ***************************************************************************
@app_state(WRITE_STATE) 
class WriteState(AppState):

    def register(self):
        self.register_transition(TERMINAL_STATE, role=Role.BOTH)
        
    def run(self):
        self.log('################## WRITE STATE #######################')
        model_dict = self.load('model_dict')
        model = model_dict['model']
        model_params_dict_agr = self.load('model_params_dict_agr')
        train_errors = self.load('train_errors')                   
        # ...expected size: trainsetsize/batchsize * number of iterations (=epochs) 

        self.log('*****Set the weights*****')
        set_the_weights(model, model_params_dict_agr, self)
        test_dataloaders = self.load('test_dataloaders')
        self.log(f'test dataloader number of batches: {len(test_dataloaders[0])}')    # dataset_len/batch_size

        acc, avg_test_loss, loss_all, y_pred_all, y_test_all, rmse = model.test(test_dataloaders)
        # if labels are float, acc will be 0, then you only look at the loss 

        self.log(f'*****R Square:*****{acc}')
        self.log(f'*****RMSE:*****{rmse}')
        self.log(f'*****Avg test loss:*****{avg_test_loss}')
        self.log(f'*****Test loss all:*****{loss_all}')
        # self.log(f'*****Predicted test labels:*****{y_pred_all}')       
        # self.log(f'*****Predicted test labels length:*****{len(y_pred_all)}')  
        # self.log(f'*****Train errors length:*****{len(train_errors)}')  


        output_file = 'TrainingAndTest'
        write_results(train_errors, loss_all, avg_test_loss, acc, y_test_all, y_pred_all, output_file)
        
        y_pred_all_numpy = np.array(y_pred_all)
        if np.array_equal(y_pred_all_numpy, y_pred_all_numpy.astype(bool)):
            y_pred_all = list(itertools.chain(*y_pred_all))    # doesn't work on continuous 
            y_test_all = list(itertools.chain(*y_test_all))
            # self.log(classification_report(y_test_all, y_pred_all))
            self.log(np.average(np.abs(np.array(y_pred_all)-np.array(y_test_all)  )))

        self.log(f'*****Save the model*****')
        model_name = self.load('model_name')
        save_model(model, model_name)

        return TERMINAL_STATE


