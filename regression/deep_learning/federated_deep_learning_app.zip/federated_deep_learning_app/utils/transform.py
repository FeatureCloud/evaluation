# *****************************************************
# ********* TRANSFORMS AND DATASET SPLIT 
# *****************************************************

import torch
import torchvision
import numpy as np
# from sklearn.preprocessing import MinMaxScaler
# from sklearn.model_selection import train_test_split
from torch.utils.data import Dataset, DataLoader
# from torchvision.transforms import ToTensor
# from torchvision import transforms, utils
from utils.read_write import read_file

# ********* TRANSFORM - SEQUENCES *********************************

# def scale_data(target):
#     scaler = MinMaxScaler(feature_range=(-1, 1))
#     target_scaled = scaler.fit_transform(target.values.reshape(-1,1))
#     return target_scaled

def make_sequences(sequence, lookback):               # create all possible sequences of length seq_len, i.e. lookback 
    data_raw = sequence   #.to_numpy() # convert to numpy array
    data = []
    for index in range(len(data_raw) - lookback): 
        data.append(data_raw[index: index + lookback])
    data = np.array(data)
    return data

# def scale_and_sequence(target, obj):
#     obj.log('Making data sequences for train and test phase...')
#     target_scaled = scale_data(target)
#     lookback = 20 # choose sequence length
#     possible_sequences = make_sequences(target_scaled, lookback)
#     obj.log(f'Posible sequences, shape:{possible_sequences.shape}')
#     return possible_sequences    
    # this is used to make sequence inputs and targets,
    # which are then split to train and test with a general split function

def seq_inputs_targets(possible_sequences):
    # if the sequence length is 20, the input feature vector's length is 19, 
    # and there is a target of lenth 1
    x = possible_sequences[:,:-1]  # inputs
    y = possible_sequences[:, -1]  # targets
    return x, y

def seq_spec_processing(seq_target, obj):
    # this is how we make our feature vectors and labels out of 1D sequence 
    obj.log('Sequence specific preprocessing...')
    possible_sequences = scale_and_sequence(seq_target, obj)             # this is preprocessing 
    x, y = seq_inputs_targets(possible_sequences)                        # read it from a file instead 
    return x, y 

# ********* DATASETS AND DATALOADERS *********************************

def data_loader_lists(train_inputs, train_targets, test_inputs, test_targets, batch_size, input_sep, device, obj):  
    data_loader_train_list = make_dataloader_list(train_inputs, train_targets, batch_size, input_sep, device, obj)
    data_loader_test_list = make_dataloader_list(test_inputs, test_targets, batch_size, input_sep, device, obj)
    return data_loader_train_list, data_loader_test_list


def make_dataloader_list(X_list, Y_list, batch_size, input_sep, device, obj):   # these are inputs and targets for train, and test 
    data_loader_list = []
    for X_file_name, Y_file_name in zip(X_list, Y_list):         # inputs and targets file name 
        transform = ToTensor()
        target_transform = ToTensor()
        data = CustomDataset(X_file_name, Y_file_name, input_sep, device, transform, target_transform, obj) 
        obj.log(f'*** DATASET LEN ***: {data.len}')
        dataloader = DataLoader(dataset=data, batch_size=batch_size, shuffle=True)
        data_loader_list.append(dataloader)                      # train and test dataloader 
    return data_loader_list 

# My ToTensor class 
# We will transform inputs and targets the same way
class ToTensor(object):
    """Convert ndarrays in sample to Tensors."""
    def __call__(self, sample):
        if torch.is_tensor(sample)==False:
            sample = torch.from_numpy(sample.astype(np.float32))    
        return sample

    
class CustomDataset(Dataset):            
    def __init__(self, X_file_name, Y_file_name, input_sep, device, transform, target_transform, obj):
        X = read_file(X_file_name, input_sep) 
        y = read_file(Y_file_name, input_sep) 
        obj.log(f'X.shape{X.shape}')
        obj.log(f'y.shape{y.shape}')
        # self.X = X.reshape(X.shape[0], X.shape[1], 1)   # must be like this for lstm 
        self.X = X
        self.y = y
        self.device = device
        self.transform = transform
        self.target_transform = target_transform
        self.len = self.X.shape[0]
       
    def __getitem__(self, index):
        if self.transform:         # .transform should be applied here 
            self.X = self.transform(self.X)            
            self.y = self.target_transform(self.y)    
        self.X = self.X.to(self.device)
        self.y = self.y.to(self.device)
        return self.X[index], self.y[index]
   
    def __len__(self):
        return self.len

