# *****************************************************
# ********* TRAIN, AGGREGATE, TEST 
# *****************************************************


import torch

def update_iteration(obj):
    iteration = obj.load('iteration')
    iteration += 1
    obj.store('iteration', iteration)
    return iteration 

def set_the_weights(model, model_params_dict_agr, obj):         # obj is for log
        for name, param in model.named_parameters():            # we need a name 
            # With transfer learning, we have the names of the layers that need to be trained, all the other
            # ones are freezed. If the name of the parameter starts with the layer name, then the weights should
            # be updated. 
            with torch.no_grad(): 
                key = name   # the param name must be in a dictionary of aggregated parameters 
                # check transfer learning:
                if key in model_params_dict_agr.keys():    # maybe it's not if we froze some layers
                    new_weights = model_params_dict_agr[key]        # for the parameter cnt 
                    # obj.log(f'New weights: {new_weights}')
                    param.copy_(new_weights)                      # very important    
                else:
                    obj.log(f'key {key} is frozen!')
                    

def agregate_params(model_params_dict_list, key_names):
    new_dict = {}                                          # this is where we store our agregated params 
    new_dict = new_dict.fromkeys(key_names, [])            # set the keys 
    for key in new_dict:                                 # for every key, first make a list 
        new_list = []
        for dict in model_params_dict_list:
            new_list.append(dict[key])
        mean_tensor_val = torch.mean(torch.stack(new_list).to(torch.float64), dim=0)   # find mean tensor values 
        new_dict[key] = mean_tensor_val                               
    return new_dict 


# extract and log the model definition 
def extract_model_definition(model_dict): 
    model = model_dict['model']
    trainable_params_list = model_dict['trainable_params_list']
    return model, trainable_params_list      

def log_model_definition(model, obj):
    obj.log('****************Model***********************')
    obj.log(f'Model: {model}')
    obj.log('****************Optimizer**********************')
    obj.log(f'Optimizer: {model.optimizer}')
    obj.log('****************Criterion***********************')
    obj.log(f'Criterion: {model.criterion}')

def update_train_errors(obj, loss):
    train_errors = obj.load('train_errors')
    train_errors = train_errors + loss
    obj.store('train_errors', train_errors)


# *****************************************************
# ********* TRANSFER LEARNING  
# *****************************************************

def freeze_all_parameters(model):
    for param in model.parameters():
        param.requires_grad = False     

def get_models_layers(model):
    layers_list=[]
    for name, module in model.named_children():     
        if not name.startswith('params'):
            layers_list.append(name)      
    return layers_list 

def log_layer_list(model, obj):
    layers_list = get_models_layers(model)  
    obj.log(f'layers_list: {layers_list}') 

def log_layers_to_change(child_string, layers_to_change, features, obj):
    obj.log(f'child_string: {child_string}')
    obj.log(f'layers_to_change: {layers_to_change}')
    obj.log(f'features: {features}')

# Check all params in model state dict, put the ones that are 
# not frozen in the list of trainable params 
def find_trainable_params(model, obj): # obj is for log 
    trainable_params_list = []
    obj.log('All model parameters:')    
    for name, param in model.named_parameters():
        obj.log(name)   
        if param.requires_grad:   # if True
            trainable_params_list.append(name)
    obj.log(f'Trainable parameters: {trainable_params_list}')
    return trainable_params_list


def remove_from_param_dict(train_params_dict, trainable_params_list):
    new_dict = {}                                        # this is where we store our agregated params 
    new_dict = new_dict.fromkeys(trainable_params_list, [])   # set the keys
    for key in new_dict:
        new_dict[key] = train_params_dict[key]
    return new_dict    

# check if you unfreezed params
def log_children_params(model, obj):    # obj is for log 
    for child in model.children():
        obj.log(f'child: {child}')
        for name, param in child.named_parameters():    # weight and bias for sequential layer no 4 are now grad true 
            obj.log(f'param_name: {name}')
            obj.log(f'param.requires_grad: {param.requires_grad}')

def change_selected_layers(layers_to_change_list, layer_indices_in_the_list, obj):
    for layer_index in layer_indices_in_the_list:               # indices list read from a config file 
        input_features = layers_to_change_list[layer_index].in_features      # this will work for any network 
        output_features = layers_to_change_list[layer_index].out_features    # inputs and outputs are connections to other layers 
        obj.log(f'Number of input features: {input_features}')
        obj.log(f'Number of output features: {output_features}')
        # take that layer out
        my_layer = layers_to_change_list[layer_index]
        obj.log(f'My layer: {my_layer}')
        # unfreeze
        for param in my_layer.parameters():
            param.requires_grad = True          
        # put the layer back
        layers_to_change_list[layer_index] = my_layer  # OR MAKE NEW, depending on what is provided in config file:  
        # features[layer_index] = torch.nn.Linear(input_features, output_features, bias = True)
    layers_to_change = torch.nn.Sequential(*layers_to_change_list)     # NOW PUT features back to the place in model.atr
    return layers_to_change


