# *****************************************************
# ********* READ, STORE, PRINT 
# *****************************************************

import bios
import pandas as pd
import torch 
from numpy import load
INPUT_DIR = '/mnt/input'     
OUTPUT_DIR = '/mnt/output'    


# *****************************************************
# **************** READ *******************************
# *****************************************************
def read_config():
    # config = bios.read(f'{INPUT_DIR}/config_tr_lr.yml')
    # config = bios.read(f'{INPUT_DIR}/config_sequence.yml')       
    config = bios.read(f'{INPUT_DIR}/config.yml') 
    train_inputs = config['train_inputs']
    train_targets = config['train_targets']
    test_inputs = config['test_inputs']
    test_targets = config['test_targets']
    input_sep = config['sep'] 
    max_iters = config['max_iters']
    device_name = config['device_name'] 
    batch_size = config['batch_size']  
    device = torch.device(device_name)
    # transfer_learning = config['transfer_learning']                               # y/n
    # model_pretrained = config['model_pretrained']                                 # model_name.pth
    # model_name = config['model_name_for_saving']                                  # for saving   
    # layers_to_train_are_children_of = config['layers_to_train_are_children_of']   # model, or model.classifier, or model.linear_relu_stack, etc...
    # layer_indices_in_the_list = config['layer_indices_in_the_list']               # one, or more layers not to freeze
    # return train_inputs, train_targets, test_inputs, test_targets, input_sep, max_iters, device, batch_size,\
    #     transfer_learning, model_pretrained, model_name, layers_to_train_are_children_of, layer_indices_in_the_list
    return train_inputs, train_targets, test_inputs, test_targets, input_sep, max_iters, device, batch_size


def read_file(input, input_sep):                                                  # inputs are for inputs or targets   
    if input.endswith('.npy'):
        data = load(f'{INPUT_DIR}/{input}', allow_pickle=True)
        # df = pd.DataFrame(data)
    else:                                                                          # or endswith('.csv')
        df = pd.read_csv(f'{INPUT_DIR}/{input}', input_sep)  
    # locations = find_unnamed_column(df) 
    # df = df.loc[:,locations]                     
    return data  


def find_unnamed_column(df):                                     
    column_headers = list(df.columns.values)                    # Unnamed, Feature1, Feature2, ...
    column_headers = [str(x) for x in column_headers]           # make a string list if there isn't one already 
    # locations = ~df.columns.str.match('Unnamed: 0')           # could be done if df.columns is a string   
    locations = []                                              # for columns that are to be left out
    key_word = 'Unnamed: 0'                                     # remove this column, it's index column 
    for i in column_headers:
        if key_word in i:
            locations.append(False)                             # do not keep 
        else:
            locations.append(True)                              # keep 
    return locations 

def read_model(model, model_name):
    model.load_state_dict(torch.load(f'{INPUT_DIR}/{model_name}'))
    return model

def read_trlr_params(obj):                                      # transfer learning parameters 
    model_pretrained = obj.load('model_pretrained')
    layers_to_train_are_children_of = obj.load('layers_to_train_are_children_of')
    layer_indices_in_the_list = obj.load('layer_indices_in_the_list')
    return model_pretrained, layers_to_train_are_children_of, layer_indices_in_the_list

def findOccurrences(s, ch):                                     # find the dot in parent model definition for transfer learning    
    return [i for i, letter in enumerate(s) if letter == ch]

def find_in_layer_list(layers_list, atr): 
    matched_indexes = []
    i = 0
    length = len(layers_list)
    while i < length:
        if atr == layers_list[i]:
            matched_indexes.append(i)
        i += 1
    child_index = matched_indexes[0] 
    return child_index
      

# ******************************************************
# **************** STORE *******************************
# ******************************************************
def store_params(train_inputs, train_targets, test_inputs, test_targets,\
    input_sep, max_iters, device, batch_size, obj):
    obj.store('train_inputs', train_inputs)
    obj.store('train_targets', train_targets)
    obj.store('test_inputs', test_inputs)
    obj.store('test_targets', test_targets)
    obj.store('input_sep', input_sep)
    obj.store('max_iters', max_iters)
    obj.store('device', device)
    obj.store('batch_size', batch_size)
    # obj.store('transfer_learning', transfer_learning)                               # y/n
    # obj.store('model_pretrained', model_pretrained)                                 # model_name.pth
    # obj.store('model_name', model_name)       
    # obj.store('layers_to_train_are_children_of', layers_to_train_are_children_of)   # model, or model.classifier, or model.linear_relu_stack, etc...
    # obj.store('layer_indices_in_the_list', layer_indices_in_the_list) 

def store_dataloaders(train_dataloaders, test_dataloaders, obj):
    obj.store('train_dataloaders', train_dataloaders)
    obj.store('test_dataloaders', test_dataloaders)


# ******************************************************
# **************** WRITE *******************************
# ******************************************************
def write_results(train_errors, loss_all, avg_test_loss, acc, y_test, predicted_test, output_file):  
    dict = {'Train errors': train_errors,'Test loss all': loss_all, 'Avg test loss': [avg_test_loss],\
        'Test acc': [acc], 'Test labels': y_test,'Predicted test labels': predicted_test}
    df = pd.DataFrame.from_dict(dict, orient='index')
    df = df.transpose()
    df.to_csv(f'{OUTPUT_DIR}/{output_file}')

def save_model(model, model_name):
    torch.save(model.state_dict(), f'{OUTPUT_DIR}/{model_name}')




# ******************************************************
# **************** PRINT/LOG ***************************
# ******************************************************
def log_config_params(train_inputs, train_targets, test_inputs, test_targets, input_sep, max_iters, device, batch_size, obj): 
    # transfer_learning, model_pretrained, layers_to_train_are_children_of, layer_indices_in_the_list, obj):    
    obj.log(f'Train Inputs:{train_inputs}')
    obj.log(f'Train Targets:{train_targets}')
    obj.log(f'Test Inputs:{test_inputs}')
    obj.log(f'Test Targets:{test_targets}')
    obj.log(f'Input separator:{input_sep}')
    obj.log(f'Max iterations:{max_iters}')
    obj.log(f'Device: {device}')
    obj.log(f'batch_size: {batch_size}')
    # obj.log(f'transfer_learning:{transfer_learning}')
    # obj.log(f'model_pretrained:{model_pretrained}')
    # obj.log(f'layers_to_train_are_children_of:{layers_to_train_are_children_of}')
    # obj.log(f'layer_indices_in_the_list:{layer_indices_in_the_list}')

def log_parameter_names(train_params_dict, obj):
    obj.log('Training params names:') 
    for k, v in train_params_dict.items():
        obj.log({k}) 

def log_dataloader_list(train_dataloaders, test_dataloaders, obj):
    obj.log(f'data_loader_train_list: {train_dataloaders}')
    obj.log(f'data_loader_test_list: {test_dataloaders}')
