
import torch
from torch import nn
import numpy as np 

# A simple, two layer neural network with ReLU activation function 
class MyModel(nn.Module):
    def __init__(self ):
        input_size = (12,4)
        learning_rate = 1e-4

        super(MyModel, self).__init__()
        self.input_size = input_size
        # self.latent_size = latent_size

        self.fc1 = nn.Linear(48, 16)
        self.fc2 = nn.Linear(16, 1)
        # self.fc3 = nn.Linear(128, 32)
        # self.fc4 = nn.Linear(32, 4)
        self.drop = nn.Dropout(p=0.3)

        self.bn1 = nn.BatchNorm1d(num_features=16, eps=1e-5, momentum=0.1, affine=False, track_running_stats=True )
        # self.bn2 = nn.BatchNorm1d(num_features=16, eps=1e-5, momentum=0.1, affine=False, track_running_stats=True )
        
        # self.softmax = nn.Softmax(dim=-1)
        self.tanh = nn.Tanh()
        self.criterion = nn.MSELoss()
        self.optimizer = torch.optim.Adam(self.parameters(), lr=learning_rate)

    def forward(self,x): 
        x= torch.flatten(x, start_dim=1)
        # print (x.shape)
        x = self.fc1(x)
        x= self.drop(x)
        x= self.bn1(x)
        
        x = self.fc2(x)
        # x= self.drop(x)
        # x= self.bn2(x)

        # x = self.fc3(x)
        # x= self.drop(x)
        # x= self.bn1(x)

        # x = self.fc4(x)
        # x= self.drop(x)
        # x= self.bn1(x)
        # print(x.shape)
        x = self.tanh(x)
        return (x)

    def train(self, train_dataloaders):             
        train_dataloader = train_dataloaders[0]
        loss_values = []
        # for X_train, y_train in train_dataloader:   
        for batch, (X_train, y_train) in enumerate(train_dataloader): 
            y_train_pred = self(X_train)
            loss = self.criterion(y_train_pred, y_train)
            loss_values.append(loss.item())
            # print("Epoch ", t, "MSE: ", loss.item()) 

            self.optimizer.zero_grad()
            loss.backward()    # check this 
            self.optimizer.step()

        # Neccessary for federated learning: 
        train_params_dict = self.state_dict()    
        return train_params_dict, loss_values, X_train

    def test(self, test_dataloaders):                          
        test_dataloader = test_dataloaders[0] 
        dataset_size = len(test_dataloader.dataset)
        num_batches = len(test_dataloader)
        y_pred_all = []    
        y_test_all = []
        test_loss = 0     # this will give avg test loss 
        loss_all = []
        total = 0
        correct = 0 
        # self.eval()
        with torch.no_grad():
            # for X_test, y_test in test_dataloader:  
            for batch, (X_test, y_test) in enumerate(test_dataloader):
                y_test_pred = self(X_test)           #y_hat               # tensors 
                total += y_test_pred.size(0)        #n                # should be the same as dataset size 
                X_test_size = X_test.size()                         # 16 x 2, but this is the last one  
                y_test_size = y_test_pred.size()                    # 16 x 1, this is the last one 
                loss = self.criterion(y_test_pred, y_test)          # if targets are ints, not needed

                y_test_pred = y_test_pred.detach().numpy()   #y_hat       # numpy arrays
                y_test = y_test.detach().numpy()             #y
                # y_test_pred = np.where(y_test_pred < 0.5, 0, 1)     # example specific 
                
                y_pred_all = y_pred_all + y_test_pred.tolist()      # add
                y_test_all = y_test_all + y_test.tolist()



                # correct += (y_test_pred == y_test).sum().item()
                loss_all.append(loss.item())
                test_loss += loss.item()
        y_hat = np.array(y_pred_all)
        y = np.array(y_test_all)
        r_sq = 1 - (np.sum(np.square(y-y_hat))/ np.sum(np.square(y - np.average(y))))
        acc = r_sq          
        rmse = (np.sum(np.square(y-y_hat))/y.shape[0])**0.5
        avg_test_loss = test_loss / num_batches
        return acc, avg_test_loss, loss_all, y_pred_all, y_test_all, rmse
        # loss is performance indicator in case of float targets 
        # y_pred_all and y_test_all can be used for classification report 
 

        