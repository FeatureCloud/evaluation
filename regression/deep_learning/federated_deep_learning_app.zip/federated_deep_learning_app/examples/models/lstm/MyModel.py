# ****************************************************************
# ********** CREATE A MODEL CLASS
# ****************************************************************

import torch
from torch import nn
import numpy as np 
# import itertools

# This model is a LSTM net 
class MyModel(nn.Module):  

    def __init__(self):    
        super(MyModel, self).__init__()
        
        input_dim = 1
        hidden_dim = 32
        num_layers = 2
        output_dim = 1
        
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers

        self.lstm = nn.LSTM(input_dim, hidden_dim, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_dim, output_dim)

        self.optimizer = torch.optim.Adam(self.parameters(), lr = 0.01)
        self.criterion = torch.nn.MSELoss(reduction = 'mean')

    def forward(self, x):
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim).requires_grad_()
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim).requires_grad_()
        out, (hn, cn) = self.lstm(x, (h0.detach(), c0.detach()))
        out = self.fc(out[:, -1, :]) 
        return out

    def train(self, train_dataloaders):    
        train_dataloader = train_dataloaders[0]    
        loss_values = []   
        for batch, (X_train, y_train) in enumerate(train_dataloader): 
        # X_train, y_train = next(iter(train_dataloader))        # same as above
            y_train_pred = self(X_train)
            loss = self.criterion(y_train_pred, y_train)
            loss_values.append(loss.item())

            self.optimizer.zero_grad()
            loss.backward()                
            self.optimizer.step()


        # Neccessary for federated learning: 
        train_params_dict = self.state_dict()
        return train_params_dict, loss_values, X_train

   
    def test(self, test_dataloaders):                           
            test_dataloader = test_dataloaders[0] 
            dataset_size = len(test_dataloader.dataset)
            num_batches = len(test_dataloader)
            y_pred_all = []    
            y_test_all = []
            test_loss = 0     # this will give avg test loss 
            loss_all = []
            total = 0
            correct = 0 
            # self.eval()
            with torch.no_grad():
                for batch, (X_test, y_test) in enumerate(test_dataloader):
                # X_test, y_test = next(iter(test_dataloader))          # a batch  
                    y_test_pred = self(X_test)                          # tensors 
                    total += y_test_pred.size(0)                        # should be the same as dataset size 
                    X_test_size = X_test.size()                         # 16 x 2, but this is the last one  
                    y_test_size = y_test_pred.size()                    # 16 x 1, this is the last one 
                    loss = self.criterion(y_test_pred, y_test)          # if targets are ints, not needed

                    y_test_pred = y_test_pred.detach().numpy()          # numpy arrays
                    y_test = y_test.detach().numpy()
                   # y_test_pred = np.where(y_test_pred < 0.5, 0, 1)    # example specific 
                    
                    y_pred_all = y_pred_all + y_test_pred.tolist()      # add new   
                    y_test_all = y_test_all + y_test.tolist()

                    correct += (y_test_pred == y_test).sum().item()
                    loss_all.append(loss.item())
                    test_loss += loss.item()
            acc = 100 * correct / total          
            avg_test_loss = test_loss / num_batches
            return acc, avg_test_loss, loss_all, y_pred_all, y_test_all
            # loss is performance indicator in case of float targets 
            # criterion might be changed with regard to training 
            # y_pred_all and y_test_all can be used for classification report 
