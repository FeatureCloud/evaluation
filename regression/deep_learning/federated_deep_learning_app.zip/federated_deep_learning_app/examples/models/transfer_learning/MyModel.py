import torch
from torch import nn
import numpy as np 
# import itertools

# A simple, two layer neural network with ReLU activation function 
# allows transfer learning 
class MyModel(nn.Module):
    def __init__(self):
        super(MyModel, self).__init__()
        self.flatten = nn.Flatten()
        self.linear_relu_stack = nn.Sequential(
            nn.Linear(2, 10),  
            nn.ReLU(),
            nn.Linear(10, 10),
            nn.ReLU(),
            nn.Linear(10, 1))
        learning_rate = 0.1
        self.criterion = nn.BCELoss()
        self.optimizer = torch.optim.SGD(self.parameters(), lr=learning_rate)

    def forward(self, x):
        x = self.flatten(x)
        logits = self.linear_relu_stack(x)
        logits = torch.nn.functional.sigmoid(logits)    
        return logits


    def train(self, train_dataloaders):             
        train_dataloader = train_dataloaders[0]                  # if there are more inputs, in this module use only the first one
        loss_values = []   
        for batch, (X_train, y_train) in enumerate(train_dataloader): 
        # X_train, y_train = next(iter(train_dataloader))        # same as above
            y_train_pred = self(X_train)
            loss = self.criterion(y_train_pred, y_train)
            loss_values.append(loss.item())

            self.optimizer.zero_grad()
            loss.backward()                
            self.optimizer.step()

        # Neccessary for federated learning: 
        train_params_dict = self.state_dict()    
        return train_params_dict, loss_values, X_train


    def test(self, test_dataloaders):                           
        test_dataloader = test_dataloaders[0] 
        dataset_size = len(test_dataloader.dataset)
        num_batches = len(test_dataloader)
        y_pred_all = []    
        y_test_all = []
        test_loss = 0     # this will give avg test loss 
        loss_all = []
        total = 0
        correct = 0 
        # self.eval()
        with torch.no_grad():
            for batch, (X_test, y_test) in enumerate(test_dataloader):
            # X_test, y_test = next(iter(test_dataloader))          # a batch  
                y_test_pred = self(X_test)                          # tensors 
                total += y_test_pred.size(0)                        # should be the same as dataset size 
                X_test_size = X_test.size()                         # 16 x 2, but this is the last one  
                y_test_size = y_test_pred.size()                    # 16 x 1, this is the last one 
                loss = self.criterion(y_test_pred, y_test)          # if targets are ints, not needed

                y_test_pred = y_test_pred.detach().numpy()          # numpy arrays
                y_test = y_test.detach().numpy()
                y_test_pred = np.where(y_test_pred < 0.5, 0, 1)     # example specific 
                
                y_pred_all = y_pred_all + y_test_pred.tolist()      # add new   
                y_test_all = y_test_all + y_test.tolist()

                correct += (y_test_pred == y_test).sum().item()
                loss_all.append(loss.item())
                test_loss += loss.item()
        acc = 100 * correct / total          
        avg_test_loss = test_loss / num_batches
        return acc, avg_test_loss, loss_all, y_pred_all, y_test_all
        # loss is performance indicator in case of float targets 
        # criterion might be changed with regard to training 
        # y_pred_all and y_test_all can be used for classification report 

 

        