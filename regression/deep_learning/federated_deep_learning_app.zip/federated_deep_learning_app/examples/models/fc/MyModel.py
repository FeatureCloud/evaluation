
import torch
from torch import nn
import numpy as np 

# A simple, two layer neural network with ReLU activation function 
class MyModel(nn.Module):
    def __init__(self):
        input_dim = 2
        hidden_dim = 10
        output_dim = 1
        super(MyModel, self).__init__()
        self.layer_1 = nn.Linear(input_dim, hidden_dim)
        nn.init.kaiming_uniform_(self.layer_1.weight, nonlinearity="relu")
        self.layer_2 = nn.Linear(hidden_dim, output_dim)

        learning_rate = 0.1
        self.criterion = nn.BCELoss()
        self.optimizer = torch.optim.SGD(self.parameters(), lr=learning_rate)
       
    def forward(self, x):
        x = torch.nn.functional.relu(self.layer_1(x))
        x = torch.nn.functional.sigmoid(self.layer_2(x))
        return x

    def train(self, train_dataloaders):             
        train_dataloader = train_dataloaders[0]
        loss_values = []
        # for X_train, y_train in train_dataloader:   
        for batch, (X_train, y_train) in enumerate(train_dataloader): 
            y_train_pred = self(X_train)
            loss = self.criterion(y_train_pred, y_train)
            loss_values.append(loss.item())
            # print("Epoch ", t, "MSE: ", loss.item()) 

            self.optimizer.zero_grad()
            loss.backward()    # check this 
            self.optimizer.step()

        # Neccessary for federated learning: 
        train_params_dict = self.state_dict()    
        return train_params_dict, loss_values, X_train

    def test(self, test_dataloaders):                          
        test_dataloader = test_dataloaders[0] 
        dataset_size = len(test_dataloader.dataset)
        num_batches = len(test_dataloader)
        y_pred_all = []    
        y_test_all = []
        test_loss = 0     # this will give avg test loss 
        loss_all = []
        total = 0
        correct = 0 
        # self.eval()
        with torch.no_grad():
            # for X_test, y_test in test_dataloader:  
            for batch, (X_test, y_test) in enumerate(test_dataloader):
                y_test_pred = self(X_test)                          # tensors 
                total += y_test_pred.size(0)                        # should be the same as dataset size 
                X_test_size = X_test.size()                         # 16 x 2, but this is the last one  
                y_test_size = y_test_pred.size()                    # 16 x 1, this is the last one 
                loss = self.criterion(y_test_pred, y_test)          # if targets are ints, not needed

                y_test_pred = y_test_pred.detach().numpy()          # numpy arrays
                y_test = y_test.detach().numpy()
                y_test_pred = np.where(y_test_pred < 0.5, 0, 1)     # example specific 
                
                y_pred_all = y_pred_all + y_test_pred.tolist()      # add
                y_test_all = y_test_all + y_test.tolist()

                correct += (y_test_pred == y_test).sum().item()
                loss_all.append(loss.item())
                test_loss += loss.item()
        acc = 100 * correct / total          
        avg_test_loss = test_loss / num_batches
        return acc, avg_test_loss, loss_all, y_pred_all, y_test_all
        # loss is performance indicator in case of float targets 
        # y_pred_all and y_test_all can be used for classification report 
 

        